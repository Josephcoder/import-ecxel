const mongoose = require('mongoose');

const provincesChema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    fullname: {
      type: String,
    },
    code: {
      type: String,
      required: true,
      unique: true,
    },
    status: {
      type: Number,
      default: 1,
      required: true,
    },
  },
  { timestamps: {} }
);

const Provinces = mongoose.model(`Provinces`, provincesChema);
module.exports = Provinces;
